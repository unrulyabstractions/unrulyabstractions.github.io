Code package for double-blind review.

This is the six-stage audit pipeline the paper reports: sources under src/,
entry points under script/, the statistics test suite under tests/, and the
generated stage configs under configs/. Install with `uv pip install -e .` and
run the suite with `uv run pytest tests/`.

Under out/ are the analysis artifacts the paper's numbers are read from: each
run's stage-6 verdict, the permutation records for the side checks, the frozen
prompts and behavior axes, the elicitation reports, the judge-seat comparison,
the robustness and ablation records, and the model organism's answer key with
our own measurements against it.

We checked what these regenerate. Running the appendix generator against this
package alone reproduces the top-candidate table, the base-free appendix, the
fold-comparison appendix, the judge-seat appendix, and the model-organism macro
file byte for byte against the submitted document.

Two things do not regenerate here, both by policy rather than by omission. The
per-reply accounting tables and the quoted reply cards are computed by scanning
the reply corpus, and the behavior-distribution figures are compiled with the
paper. The corpus, the organism weights, and third-party organism checkpoints
are not redistributed; the paper's reproducibility statement covers data
availability, and the printed values for both appear in the submitted appendix.
